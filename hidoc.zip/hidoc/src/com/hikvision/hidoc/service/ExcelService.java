package com.hikvision.hidoc.service;

import com.hikvision.hidoc.model.vo.ExcelCellVo;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

/**
 * @author jinxm
 * @date 2023-08-16 23:55:56
 * @description
 */
public interface ExcelService {

    List<List<ExcelCellVo>> analyzeExcel(InputStream is);
}
