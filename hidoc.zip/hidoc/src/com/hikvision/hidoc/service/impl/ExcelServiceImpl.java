package com.hikvision.hidoc.service.impl;

import com.hikvision.hidoc.model.vo.ExcelCellVo;
import com.hikvision.hidoc.service.ExcelService;
import org.apache.poi.ss.formula.eval.ErrorEval;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.util.LocaleUtil;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * @author jinxm
 * @date 2023-08-16 23:56:16
 * @description
 */
public class ExcelServiceImpl implements ExcelService {

    /**
     * 分析excl
     *
     * @param is
     * @return
     * @throws Exception
     */
    @Override
    public List<List<ExcelCellVo>> analyzeExcel(InputStream is)  {
        try {
            Workbook wb = new XSSFWorkbook(is);
            //根据sheet页创建map集合
                //读取sheet页
                Sheet sheet = wb.getSheetAt(0);
                if (sheet != null) {
                    //创建list集合
                    List<List<ExcelCellVo>> data = new ArrayList<>();
                    // 遍历行
                    for (int i = 0; i <= sheet.getLastRowNum(); i++) {
                        //获得行
                        Row row = sheet.getRow(i);
                        //创建list集合
                        List<ExcelCellVo> colData = new ArrayList<>();
                        //遍历列
                        if (row != null) {
                            for (int j = 0; j < row.getLastCellNum(); j++) {
                                //获取单元格
                                Cell cell = row.getCell(j);
                                //获取字体
                                Font eFont = wb.getFontAt(cell.getCellStyle().getFontIndex());
                                colData.add(getCellVo(cell, eFont));
                            }
                            data.add(colData);
                        }
                    }
                    return data;
                }
            throw new RuntimeException("sheet不存在");
        } catch (Exception e) {
            throw new RuntimeException("解析Excel错：" + e.getMessage());
        }
    }

    /**
     * 获取单元格vo
     *
     * @param cell  单元格
     * @param eFont 字体
     * @return
     */
    private ExcelCellVo getCellVo(Cell cell, Font eFont) {
        //创建单元格对象
        ExcelCellVo dto = new ExcelCellVo();
        if (cell != null && eFont != null) {
            //值
            switch (cell.getCellType()) {
                case NUMERIC:
                    if (DateUtil.isCellDateFormatted(cell)) {
                        DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", LocaleUtil.getUserLocale());
                        sdf.setTimeZone(LocaleUtil.getUserTimeZone());
                        dto.setValue(sdf.format(cell.getDateCellValue()));
                    } else {
                        DataFormatter formatter = new DataFormatter();
                        dto.setValue(formatter.formatCellValue(cell));
                    }
                    break;
                case STRING:
                    dto.setValue(cell.getStringCellValue());
                    break;
                case BOOLEAN:
                    dto.setValue(String.valueOf(cell.getBooleanCellValue()));
                    break;
                case FORMULA:
                    dto.setValue(cell.getCellFormula());
                    break;
                case BLANK:
                    dto.setValue("");
                    break;
                case ERROR:
                    dto.setValue(ErrorEval.getText(cell.getErrorCellValue()));
                    break;
                default:
                    dto.setValue("Unknown Cell Type: " + cell.getCellType());
            }
            // xlsx 07版
            //背景颜色
            CellStyle cellStyle = cell.getCellStyle();
            XSSFColor xssfColor = (XSSFColor) cellStyle.getFillForegroundColorColor();
            byte[] bytes;
            if (xssfColor != null) {
                bytes = xssfColor.getRGB();
                dto.setBackgroundColor(String.format("#%02X%02X%02X", bytes[0], bytes[1], bytes[2]));
            }
            //获取字体
            XSSFFont f = (XSSFFont) eFont;
            //字体颜色
            XSSFColor xssffont = f.getXSSFColor();
            byte[] rgb;
            if (xssffont != null) {
                //得到rgb的byte数组
                rgb = xssffont.getRGB();
                dto.setFontColor(String.format("#%02X%02X%02X", rgb[0], rgb[1], rgb[2]));
            }
        }
        return dto;
    }
}
