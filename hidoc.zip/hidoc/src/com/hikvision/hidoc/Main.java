package com.hikvision.hidoc;

import com.hikvision.hidoc.model.vo.ExcelCellVo;
import com.hikvision.hidoc.service.ExcelService;
import com.hikvision.hidoc.service.impl.ExcelServiceImpl;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.List;

/**
 * @author jinxm
 * @date 2023-08-16 23:22:44
 * @description
 */
public class Main {

    public static void main(String[] args) throws Exception {
        ExcelService excelService = new ExcelServiceImpl();
        InputStream input = new FileInputStream("C:\\Users\\xiaomiaoOba\\Desktop\\test.xlsx");
        List<List<ExcelCellVo>> listMap = excelService.analyzeExcel(input);
        //debug看结果
        System.out.println(listMap);

    }
}
