package com.hikvision.hidoc.model.vo;

/**
 * @author jinxm
 * @date 2023-08-17 0:04:34
 * @description
 */
public class ExcelCellVo {

    /**
     * 值
     */
    private String value = "";

    /**
     * 背景色
     */
    private String backgroundColor = "";

    /**
     * 文字颜色
     */
    private String fontColor = "";

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getBackgroundColor() {
        return backgroundColor;
    }

    public void setBackgroundColor(String backgroundColor) {
        this.backgroundColor = backgroundColor;
    }

    public String getFontColor() {
        return fontColor;
    }

    public void setFontColor(String fontColor) {
        this.fontColor = fontColor;
    }
}
